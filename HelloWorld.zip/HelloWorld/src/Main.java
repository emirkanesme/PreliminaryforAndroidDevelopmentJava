import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static ArrayList<Contact> contacts;
    private static Scanner scanner;
    private static int id = 0;
    public static void main(String[] args) {

        contacts = new ArrayList<>();
        System.out.println("Welcome to ebbys Challange 1");
        showInitialOptions();
    }

    private static void showInitialOptions() {
        System.out.println("1. Manage contacts");
        System.out.println("2. Messages");
        System.out.println("3. Quit");
        scanner = new Scanner(System.in);
        int choice = scanner.nextInt();
        switch (choice){
            case 1:
                manageContacts();
                break;
            case 2:
                manageMessages();
                break;
            default:
                break;
        }
    }

    private static void manageMessages() {
        System.out.println("1. Show all messages");
        System.out.println("2. Send a new message");
        System.out.println("3. Go back");
        int choice = scanner.nextInt();
        switch (choice){
            case 1:
                showAllMessages();
                break;
            case 2:
                sendMessage();
                break;
            default:
                showInitialOptions();
                break;
        }
    }

    private static void sendMessage() {
        System.out.println("Whom you going to send the message : ");
        String name = scanner.next();
        if(name.equals("")){
            System.out.println("Enter name correctly ! ");
            sendMessage();
        }else{
            boolean doesExist = false;
            for(Contact c:contacts){
                if(c.getName().equals(name)){
                    doesExist = true;
                }
            }
            if(doesExist){
                System.out.println("Write your message : ");
                String text = scanner.next();
                if(text.equals("")){
                    System.out.println("Please enter some message");
                    sendMessage();
                }else{
                    id++;
                    Message newMessage = new Message(text,name,id);
                    for(Contact c:contacts){
                        if(c.getName().equals(name)){
                            ArrayList<Message> newMessages = c.getMessages();
                            newMessages.add(newMessage);
                            Contact currentContact = c;
                            currentContact.setMessages(newMessages);
                            contacts.remove(c);
                            contacts.add(currentContact);
                        }
                    }

                }
            }else{
                System.out.println("There is no such contact");
            }
        }
        showInitialOptions();
    }

    private static void showAllMessages() {
        ArrayList<Message> allMessages = new ArrayList<>();
        for(Contact c:contacts){
            allMessages.addAll(c.getMessages());
        }
        if(allMessages.size()>0){
            for(Message m:allMessages){
                m.getDetais();
                System.out.println("******************************");
            }
        }else{
            System.out.println("You dont have any messages");
        }
        showInitialOptions();
    }

    private static void manageContacts() {
        System.out.println("1. Show all contacts");
        System.out.println("2. Add a new contact");
        System.out.println("3. Search for a contact");
        System.out.println("4. Delete a contact");
        System.out.println("5. Go back");
        int choice = scanner.nextInt();
        switch (choice){
            case 1:
                showAllContacts();
                break;
            case 2:
                addNewContact();
                break;
            case 3:
                searchForContact();
                break;
            case 4:
                deleteContact();
                break;
            default:
                showInitialOptions();
                break;

        }
    }

    private static void deleteContact() {
        System.out.println("Please enter name : ");
        String name = scanner.next();
        if(name.equals("")){
            System.out.println("Enter correctly !");
            deleteContact();
        }else{
            boolean doesExist = false;
            for(Contact c:contacts){
                if(c.getName().equals(name)){
                    doesExist=true;
                    contacts.remove(c);
                }
            }
            if(!doesExist){
                System.out.println("There is no such contact !");
            }
        }
        showInitialOptions();
    }

    private static void searchForContact() {
        System.out.println("Please enter the contacts name");
        String name = scanner.next();
        if(name.equals("")){
            System.out.println("Enter name correctly !");
            searchForContact();
        }else{
            boolean doesExist = false;
            for(Contact c:contacts){
                if(c.getName().equals(name)){
                    doesExist = true;
                    c.getDetails();
                }
                if(!doesExist) System.out.println("There is no such contact !");

            }
        }
        showInitialOptions();
    }

    private static void addNewContact() {
        System.out.println("Adding new contact...\nPlease enter name:");
        String name = scanner.next();
        System.out.println("Please enter number : ");
        String number = scanner.next();
        System.out.println("Please enter email : ");
        String email = scanner.next();
        if(name.equals("") || number.equals("")||email.equals("")){
            System.out.println("Please enter all information correctly !");
            addNewContact();
        }else{
            boolean doesExist = false;
            for(Contact c:contacts){
                if(c.getName().equals(name)){
                    doesExist = true;
                }
            }
            if(doesExist){
                System.out.println("We found contact "+name+" saved before");
                addNewContact();
            }else{
                Contact contact = new Contact(name,number,email);
                contacts.add(contact);
                System.out.println("Name added successfully");
            }

        }
        showInitialOptions();

    }

    private static void showAllContacts() {
        for(Contact c:contacts){
            c.getDetails();
            System.out.println("***************************");
        }
        showInitialOptions();
    }
}
