import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Library myLibrary = new Library();
        Scanner scanner = new Scanner(System.in);
        while(true){
            optionsMenu();
            int choice = scanner.nextInt();
            switch (choice){
                case 1:
                    System.out.println("Enter title : ");
                    String title = scanner.next();
                    System.out.println("Enter author : ");
                    String author = scanner.next();
                    System.out.println("Enter isbn : ");
                    String isbn = scanner.next();
                    myLibrary.addBook(title,author,isbn);
                    break;
                case 2:
                    System.out.println("Enter name of the book that you want to remove : ");
                    String name = scanner.next();
                    myLibrary.removeBook(name);
                    break;
                case 3:
                    System.out.println("Enter address : ");
                    String address = scanner.next();
                    System.out.println("Enter name : ");
                    String nameP = scanner.next();
                    System.out.println("Enter phone : ");
                    String phone = scanner.next();
                    myLibrary.addMember(address,nameP,phone);
                    break;
                case 4:
                    System.out.println("Enter name of the person that you want to remove : ");
                    String namePe = scanner.next();
                    myLibrary.removeMember(namePe);
                    break;
                case 5:
                    myLibrary.seeAllBooks();
                    break;
                case 6:
                    myLibrary.seeAllMembers();
                    break;
                default:
                    break;
            }
        }


    }


    public static void optionsMenu(){
        System.out.println("Choose your option : ");
        System.out.println("1. Add Book");
        System.out.println("2. Remove Book");
        System.out.println("3. Add Member");
        System.out.println("4. Remove Member");
        System.out.println("5. See All Books");
        System.out.println("6. See All Members");
        System.out.println("7. Exit");

    }
}
