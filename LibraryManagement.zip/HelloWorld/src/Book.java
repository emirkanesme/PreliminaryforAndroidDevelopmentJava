public class Book {
    private String bookTitle;
    private String bookAuthor;
    private String bookISBN;

    public Book(String bookTitle, String bookAuthor, String bookISBN) {
        this.bookTitle = bookTitle;
        this.bookAuthor = bookAuthor;
        this.bookISBN = bookISBN;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public String getBookISBN() {
        return bookISBN;
    }

    public void setBookISBN(String bookISBN) {
        this.bookISBN = bookISBN;
    }

    public void getDetail() {
        System.out.println("Title : "+this.bookTitle);
        System.out.println("Author : "+this.bookAuthor);
        System.out.println("ISBN : "+this.bookISBN);
    }
}
