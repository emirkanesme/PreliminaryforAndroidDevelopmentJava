public class Member {
    private String memberAddress;
    private String memberName;
    private String memberNo;

    public Member(String memberAddress, String memberName, String memberNo) {
        this.memberAddress = memberAddress;
        this.memberName = memberName;
        this.memberNo = memberNo;
    }




    public String getMemberAddress() {
        return memberAddress;
    }

    public void setMemberAddress(String memberAddress) {
        this.memberAddress = memberAddress;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberNo() {
        return memberNo;
    }

    public void setMemberNo(String memberNo) {
        this.memberNo = memberNo;
    }

    public void getDetail() {
        System.out.println("Name : "+this.memberName);
        System.out.println("Address : "+this.memberAddress);
        System.out.println("Phone : "+this.memberNo);
    }
}
