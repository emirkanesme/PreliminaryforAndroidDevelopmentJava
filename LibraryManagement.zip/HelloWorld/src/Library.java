import java.util.ArrayList;

public class Library {
    private ArrayList<Book> books = new ArrayList<>();
    private ArrayList<Member> members = new ArrayList<>();
    private int bookCount , memberCount;

    public Library() {
        this.books = new ArrayList<>();
        this.members = new ArrayList<>();
        this.bookCount = 0;
        this.memberCount = 0;
    }
    public Library(ArrayList<Book> books, ArrayList<Member> members, int bookCount, int memberCount) {
        this.books = books;
        this.members = members;
        this.bookCount = bookCount;
        this.memberCount = memberCount;
    }


    public Library(ArrayList<Book> books, ArrayList<Member> members) {
        this.books = books;
        this.members = members;
        this.bookCount = 0;
        this.memberCount=0;
    }

    public void seeAllMembers(){
        for(Member member:members){
            member.getDetail();

        }
    }
    public void seeAllBooks(){
        for(Book book:books){
            book.getDetail();

        }
    }

    public void addBook(String title, String author, String isbn){
        Book newBook = new Book(title,author,isbn);
        books.add(newBook);
        bookCount++;
    }
    public void removeMember(String name){
        boolean doesExist = false;
        for(Member member:members){
            if(member.getMemberName().equals(name)){
                doesExist = true;
                memberCount--;
                members.remove(member);
            }
        }
        if(doesExist){
            System.out.println("Member deleted !");
        }else{
            System.out.println("Member not found !");
        }


    }
    public void addMember(String memberAddress, String memberName, String memberNo){
        Member newMember = new Member(memberAddress,memberName,memberNo);
        members.add(newMember);
        memberCount++;
    }
    public void removeBook(String name){
        boolean doesExist = false;
        for(Book book:books){
            if(book.getBookTitle().equals(name)){
                doesExist = true;
                bookCount--;
                books.remove(book);
            }
        }
        if(doesExist){
            System.out.println("Book deleted !");
        }else{
            System.out.println("Book not found !");
        }

    }
}
